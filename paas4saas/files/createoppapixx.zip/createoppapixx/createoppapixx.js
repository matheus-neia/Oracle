/**
 * The ExpressJS namespace.
 * @external ExpressApplicationObject
 * @see {@link http://expressjs.com/3x/api.html#app}
 */ 

/**
 * Mobile Cloud custom code service entry point.
 * @param {external:ExpressApplicationObject}
 * service 
 */
module.exports = function(service) {


	/**
	 *  The file samples.txt in the archive that this file was packaged with contains some example code.
	 */


	service.post('/mobile/custom/CreateOppAPIXX/opportunity', function(req,res) {
		console.log("Teste 1 " + req.body['name']);
		var sdk = req.oracleMobile;
		var optionsList = {
			Header: null,
		    Body: {
						"start" : {
							"formArg" : {
								"Opportunity": {
					               "opportunityName": req.body['name'],
					               "owner": req.body['owner'],
					               "winProb": req.body['winProb'],
					               "productName": req.body['productName'],
					               "productPrice": req.body['productPrice'],
					               "productQty": req.body['productQty']
					            }
							}
						}
					}
		};

		sdk.connectors.post('CreateOppPCSConnectorXX', 'start', optionsList, {inType: 'json', versionToInvoke: '1.0'}).then(
    				function (result) {
      					res.status(result.statusCode).send(result.result);
    				},
				    function (error) {      
				      	res.status(error.statusCode).send(error.error);
				    }
				  );
	});

	service.get('/mobile/custom/CreateOppAPIXX/opportunity', function(req,res) {
		var result = {};
		var statusCode = 200;
		if (statusCode == 200){
			var acceptType = req.accepts(['application/json']);
			if (acceptType == 'application/json'){
				result = [
					    {
					        "id": "1558019767795",
					        "name": "opportunityName45",
					        "owner": "owner46",
					        "winProb": "10",
					        "productName": "productName48",
					        "productPrice": 0,
					        "productQty": 0
					    }
					];
			}
		}
		res.status(statusCode).send(result);
	});

	service.patch('/mobile/custom/CreateOppAPIXX/opportunity/:id', function(req,res) {
		var result = {};
		var statusCode = 200;
		res.status(statusCode).send(result);
	});

	service.delete('/mobile/custom/CreateOppAPIXX/opportunity/:id', function(req,res) {
		var result = {};
		var statusCode = 200;
		res.status(statusCode).send(result);
	});

	service.get('/mobile/custom/CreateOppAPIXX/opportunity/:id', function(req,res) {
		var result = {};
		var statusCode = 200;
		res.status(statusCode).send(result);
	});

};
